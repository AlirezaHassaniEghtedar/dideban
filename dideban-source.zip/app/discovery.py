"""Discover announcement links on approved pages for human source approval."""
from urllib.parse import urljoin, urlsplit
from bs4 import BeautifulSoup
from sqlalchemy import insert, select
from sqlalchemy.exc import IntegrityError
from .db import candidates, sources
from .extract import norm
from .fetch import canonical

def discover(html, origin):
    soup = BeautifulSoup(html,"html.parser")
    found = {}
    for link in soup.select("a[href]"):
        title = norm(link.get_text(" ",strip=True))
        if not any(word in title for word in ("امریه","کسری خدمت","جایگزین خدمت","سرباز فناور","سرباز نخبگی")):
            continue
        try:
            url = canonical(urljoin(origin,link["href"]))
        except ValueError:
            continue
        if url != origin and urlsplit(url).netloc == urlsplit(origin).netloc and len(url)<=2048:
            found[url] = title[:200]
        if len(found)>=30:
            break
    return found

def save_candidates(conn, origin, links):
    for url,title in links.items():
        if conn.scalar(select(sources.c.id).where(sources.c.url==url)):
            continue
        try:
            with conn.begin_nested():
                conn.execute(insert(candidates).values(url=url,title=title,origin=origin))
        except IntegrityError:
            continue

